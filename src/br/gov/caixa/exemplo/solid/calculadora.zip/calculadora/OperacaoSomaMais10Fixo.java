package br.gov.caixa.exemplo.solid.calculadora;

public class OperacaoSomaMais10Fixo extends OperacaoSoma {

    public int somar(int valor1, int valor2) {
        return 10 + valor1 + valor2;
    }
}
