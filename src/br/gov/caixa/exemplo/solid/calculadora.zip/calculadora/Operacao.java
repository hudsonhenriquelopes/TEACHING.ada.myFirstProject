package br.gov.caixa.exemplo.solid.calculadora;

public interface Operacao {
    int executar(int valor1, int valor2);
}
