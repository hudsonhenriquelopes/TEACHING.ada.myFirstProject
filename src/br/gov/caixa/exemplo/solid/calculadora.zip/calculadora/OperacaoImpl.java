package br.gov.caixa.exemplo.solid.calculadora;

public abstract class OperacaoImpl implements Operacao {
    private Integer atributoQualquer;

//    public int executar(int valor1, int valor2) {
//        return 0;
//    }

    public String metodoAleatorio() {
        return "";
    }
}
